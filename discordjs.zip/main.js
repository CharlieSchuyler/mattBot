const Discord = require("discord.js");
const client = new Discord.Client();

const token = "NzQ5OTkxMTY2OTA4NTYzNDc2.X00BtA.0h0QXvZKT2Ej04YjYZOjch1_zYg";

const PREFIX = "$";

let forbiddenWords = ["this sucks", "turn it off", "turn the bot off"];
let safeWords = ["i love this bot", "$help", "$stop", "$start"];
stop = false;
//starts the bot as dnd

client.on("ready", () => {
	console.log("The client is ready!");
	client.user.setPresence({
		status: "dnd",
		game: {
			name: "Type !help",
			type: 0,
		}, // You can show online, idle... Do not disturb is dnd
	});
});

//help

client.on("message", (message) => {
	if (message.content === "$help") {
		message.channel.send(`$help = gives you this command - $stop = stops the bot - $start = starts the bot`);
	}
});

//starts and stops

client.on("message", (message) => {
	if (message.content === "$stop") {
		if (!stop) {
			stop = true;
			message.channel.send(`bot has been stopped thanks to ${message.author.tag}`);
			message.author.send("fuck you");
		}
	}
	if (message.content === "$start") {
		if (stop) {
			stop = false;
			message.channel.send(`bot has been started thanks to ${message.author.tag}`);
		}
	}
});

//forbiddon words and matt bot

client.on("message", (message) => {
	if (stop) return;
	if (message.author.bot) return;
	if (forbiddenWords.includes(message.content)) {
		message.delete({ timeout: 20 });
		console.log(`deleted message sent by : ${message.author.tag} - ${message.content} `);
		message.channel.send(`deleted message sent by : ${message.author.tag} \nMessage Content : ${message.content}`);

		message.author.send("I have caught you using volger language this can lead to a punishment, i better not catch you again");
		return;
	}

	if ((message.author.id = 345372933020975106)) {
		if (!safeWords.includes(message.content)) {
			message.channel.send("stfu");
			console.log("messeged");
		} else {
			return;
		}
	} else {
		return;
	}
});

//if ((msg.author.id = "345372933020975106")) {
client.login(token);
